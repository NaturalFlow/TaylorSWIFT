//: Playground - noun: a place where people can play
import UIKit

class City {
    var name: String
    var population: Int
    var area: Float
    
    func densityForKm2()->Float{
        return area/Float(population);
    }
    init(_ name: String, _ population: Int, _ area: Float){
        self.name = name
        self.population = population
        self.area = area
    }
};


var cities = Array<City>()

let tokyo = City("Tokyo",13617444, 2187.66)
let sanFrancisco = City("San Francisco",884363,600.59)
let saoPaulo = City("Sao Paulo", 12106920, 1521.11)

cities.append(contentsOf: [tokyo, sanFrancisco, saoPaulo])
//Search using filter
let SF = cities.filter{(city:City) -> Bool in
    return city.name == "San Francisco"
}
print(SF[0].name)
//Search using map
var citiesDic = [String: City]()

for city in cities {
    citiesDic[city.name] = city
}
print(citiesDic["San Francisco"]?.name ?? "")

if let cityName = citiesDic["San Francisco"] {
    print(cityName)
}
//Count the numbers and the ocurrence of vowels in a string

func howMuchVowel(word: String) -> [Character: Int] {
    var ocurrence = [Character: Int]()
    let vowels: [Character] = ["a", "e", "i", "o", "u"]
    for vowel in word.characters {
        if vowels.contains(vowel) {
            if ocurrence[vowel] == nil {
                ocurrence[vowel] = 1
            }else {
                ocurrence[vowel]! += 1
            }
        }
    }
    return ocurrence
 }
let ocurrence = howMuchVowel(word: "WhatShouldNinjaDo")
for vowel in ocurrence.keys {
    for count in 0..<ocurrence[vowel]! {
        print(vowel)
    }
}
/*
func download(url: String,
          success: ((City) ->Void),
         failured: (() -> Void))
{
    if url.contains("g") {
        success(City("goiania", 100, 300))
    } else {
        failured()
    }
}
download(url: "www.google.com", success: { (city) in
    print("\(city.name)")
}) {
    print("sorry")
}
*/
